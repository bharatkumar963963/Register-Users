import './App.css';
import RegisterForm from './components/RegisterForm';
import UserList from './components/UserList';

function App() {
  return (
    <div>
      <RegisterForm />
      <UserList />
    </div>
  );
}

export default App;

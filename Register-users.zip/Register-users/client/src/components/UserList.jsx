import React from 'react';
import { connect } from 'react-redux';

const UserList = ({ users }) => {
  return (
    <div>
      <h2>User List:</h2>
      <ul>
        {users.map((user, index) => (
          <li key={index}>
            Name: {user.name}, Mobile No: {user.mobile}
          </li>
        ))}
      </ul>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    users: state.users,
  };
};

export default connect(mapStateToProps)(UserList);
